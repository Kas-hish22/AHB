`timescale 1ns/1ps

module AHB_tb ();
    // Processor / Interface Testbench Signals
    reg        HCLK;
    reg        HRESETn;
    reg [31:0] PADDR;
    reg [31:0] PWDATA;
    reg        PWRITE;
    reg [2:0]  PSIZE;
    reg [1:0]  PTRANS;
    reg [2:0]  PBURST;
    wire       PDONE;

    // Instantiate AHB_TOP Module
    AHB_TOP top (
        .HCLK(HCLK),
        .HRESETn(HRESETn),
        .PADDR(PADDR),
        .PWDATA(PWDATA),
        .PWRITE(PWRITE),
        .PSIZE(PSIZE),
        .PTRANS(PTRANS),
        .PBURST(PBURST),
        .PDONE(PDONE)
    );

    // Clock Generation: 50 MHz (20ns Period)
    initial begin
        HCLK = 0;
        forever #10 HCLK = ~HCLK;
    end

    // Simulation Sequence (Task 2: 5 Comprehensive Test Cases)
    initial begin
        // -------------------------------------------------------------
        // System Reset Initialization
        // -------------------------------------------------------------
        HRESETn = 0;
        PADDR   = 32'h0;
        PWDATA  = 32'h0;
        PWRITE  = 0;
        PSIZE   = 3'b000;
        PTRANS  = 2'b00;
        PBURST  = 3'b000;
        #40;
        HRESETn = 1;
        @(posedge HCLK);

        // =============================================================
        // Test Case 1: Single Write Transfer (No Wait-state)
        // Target: Slave 1 (Addr: 0x00000004), Size: 32-bit (0xDEADBEEF)
        // =============================================================
        $display("\n[%0t ns] --- TEST CASE 1: Single Write Transfer ---", $time);
        @(posedge HCLK);
        PADDR  <= 32'h00000004; // Address Phase
        PWDATA <= 32'hDEADBEEF; // Data Phase value
        PWRITE <= 1'b1;         // Write
        PSIZE  <= 3'b010;        // 32-bit
        PTRANS <= 2'b10;         // NONSEQ
        PBURST <= 3'b000;        // SINGLE

        @(posedge HCLK);
        PTRANS <= 2'b00;         // Move to IDLE (Data Phase completes)
        @(posedge HCLK);

        // =============================================================
        // Test Case 2: Single Read Transfer (No Wait-state)
        // Target: Slave 1 (Addr: 0x00000004), Read back 32-bit data
        // =============================================================
        $display("\n[%0t ns] --- TEST CASE 2: Single Read Transfer ---", $time);
        @(posedge HCLK);
        PADDR  <= 32'h00000004; // Address Phase
        PWRITE <= 1'b0;         // Read
        PSIZE  <= 3'b010;        // 32-bit
        PTRANS <= 2'b10;         // NONSEQ
        PBURST <= 3'b000;        // SINGLE

        @(posedge HCLK);
        PTRANS <= 2'b00;         // IDLE (Read Data sampled)
        @(posedge HCLK);

        // =============================================================
        // Test Case 3: Write with Wait-state Insertion
        // Target: Slave 2 (Addr: 0x40000000), Data: 0xCAFE1234
        // =============================================================
        $display("\n[%0t ns] --- TEST CASE 3: Write with Wait-State ---", $time);
        @(posedge HCLK);
        PADDR  <= 32'h40000000; // Slave 2 base address
        PWDATA <= 32'hCAFE1234;
        PWRITE <= 1'b1;
        PSIZE  <= 3'b010;        // 32-bit
        PTRANS <= 2'b10;         // NONSEQ
        PBURST <= 3'b000;

        @(posedge HCLK);
        PTRANS <= 2'b00;         // IDLE
        @(posedge HCLK);

        // =============================================================
        // Test Case 4: Burst Transfer (INCR4 - 4 transfers, 8-bit)
        // Target: Slave 1 (Addr: 0x00000010 to 0x00000013)
        // =============================================================
        $display("\n[%0t ns] --- TEST CASE 4: Burst Transfer (INCR) ---", $time);
        @(posedge HCLK);
        // Beat 1 (NONSEQ)
        PADDR  <= 32'h00000010;
        PWDATA <= 32'hAA;
        PWRITE <= 1'b1;
        PSIZE  <= 3'b000;        // 8-bit
        PTRANS <= 2'b10;         // NONSEQ
        PBURST <= 3'b001;        // INCR

        @(posedge HCLK);
        // Beat 2 (SEQ)
        PWDATA <= 32'hBB;
        PTRANS <= 2'b11;         // SEQ

        @(posedge HCLK);
        // Beat 3 (SEQ)
        PWDATA <= 32'hCC;
        PTRANS <= 2'b11;         // SEQ

        @(posedge HCLK);
        // Beat 4 (SEQ)
        PWDATA <= 32'hDD;
        PTRANS <= 2'b11;         // SEQ

        @(posedge HCLK);
        PTRANS <= 2'b00;         // IDLE
        @(posedge HCLK);

        // =============================================================
        // Test Case 5: Invalid Address with Error Response
        // Target: Unmapped region (Addr: 0x80000000 / Slave 3 select)
        // =============================================================
        $display("\n[%0t ns] --- TEST CASE 5: Invalid Address Transfer ---", $time);
        @(posedge HCLK);
        PADDR  <= 32'h80000000; // Selects unmapped Slave 3 space
        PWRITE <= 1'b0;         // Read
        PSIZE  <= 3'b010;
        PTRANS <= 2'b10;         // NONSEQ
        PBURST <= 3'b000;

        @(posedge HCLK);
        PTRANS <= 2'b00;         // IDLE
        #40;

        $display("\n[%0t ns] --- All 5 Test Cases Executed Successfully ---", $time);
        $stop;
    end

endmodule