
module AHB_Lite_Master (
    // Global Signals
    input             HCLK,
    input             HRESETn,
    
    // Processor Signals (Testbench Interface)
    input      [31:0] PADDR,
    input      [31:0] PWDATA,
    input             PWRITE,
    input      [2:0]  PSIZE,
    input      [1:0]  PTRANS,
    input      [2:0]  PBURST,
    
    // Transfer Response from Slave / MUX
    input             HREADY,      // Wait-state indicator (0 = Wait, 1 = Ready)
    input             HRESP,
    input      [31:0] HRDATA,
    
    // AHB Bus Outputs
    output reg [31:0] HADDR,
    output reg [31:0] HWDATA,
    output reg        HWRITE,
    output reg [2:0]  HSIZE,
    output reg [1:0]  HTRANS,
    output reg [2:0]  HBURST,
    output reg        PDONE
);

    // AHB State Definitions
    localparam IDLE   = 2'b00;
    localparam BUSY   = 2'b01;
    localparam NONSEQ = 2'b10;
    localparam SEQ    = 2'b11;

    reg [1:0]  cs, ns;
    reg [31:0] HWDATA_reg;

    // 1. State Memory (Respects HREADY for Wait States)
    always @(posedge HCLK or negedge HRESETn) begin
        if (!HRESETn)
            cs <= IDLE;
        else if (HREADY) // Wait-state hone par state freeze rahegi
            cs <= ns;
    end

    // 2. Next State Logic
    always @(*) begin
        case (cs)
            IDLE: begin
                if (PTRANS == 2'b10)
                    ns = NONSEQ;
                else
                    ns = IDLE;
            end

            BUSY: begin
                if (PTRANS == 2'b11)
                    ns = SEQ;
                else if (PTRANS == 2'b10)
                    ns = NONSEQ;
                else if (PTRANS == 2'b00)
                    ns = IDLE;
                else
                    ns = BUSY;
            end

            NONSEQ: begin
                if (PTRANS == 2'b11)
                    ns = SEQ;
                else if (PTRANS == 2'b00)
                    ns = IDLE;
                else if (PTRANS == 2'b10 && PBURST == 3'b000)
                    ns = NONSEQ;
                else
                    ns = SEQ;
            end

            SEQ: begin
                if (PTRANS == 2'b00)
                    ns = IDLE;
                else if (PTRANS == 2'b10)
                    ns = NONSEQ;
                else
                    ns = SEQ;
            end

            default: ns = IDLE;
        endcase
    end

    // 3. Address & Control Output Logic (Gated by HREADY)
    always @(posedge HCLK or negedge HRESETn) begin
        if (!HRESETn) begin
            HADDR      <= 32'b0;
            HWDATA_reg <= 32'b0;
            HWRITE     <= 1'b0;
            HSIZE      <= 3'b000;
            HTRANS     <= 2'b00;
            HBURST     <= 3'b000;
        end 
        else if (HREADY) begin // Agar Slave ready na ho (HREADY=0), address/control hold rahega
            case (cs)
                IDLE: begin
                    HADDR      <= 32'b0;
                    HWDATA_reg <= 32'b0;
                    HWRITE     <= 1'b0;
                    HSIZE      <= 3'b000;
                    HTRANS     <= 2'b00;
                    HBURST     <= 3'b000;
                end

                BUSY, NONSEQ: begin
                    HADDR      <= PADDR;
                    HWDATA_reg <= PWDATA;
                    HWRITE     <= PWRITE;
                    HSIZE      <= PSIZE;
                    HTRANS     <= PTRANS;
                    HBURST     <= PBURST;
                end

                SEQ: begin
                    HWRITE     <= PWRITE;
                    HSIZE      <= PSIZE;
                    HTRANS     <= PTRANS;
                    HBURST     <= PBURST;
                    
                    if (PBURST == 3'b001) begin // Incremental Burst
                        case (PSIZE)
                            3'b000: begin // 8-bit
                                HADDR      <= HADDR + 1'b1;
                                HWDATA_reg <= {24'h000000, PWDATA[7:0]};
                            end
                            3'b001: begin // 16-bit
                                HADDR      <= HADDR + 2'd2;
                                HWDATA_reg <= {16'h0000, PWDATA[15:0]};
                            end
                            3'b010: begin // 32-bit
                                HADDR      <= HADDR + 3'd4;
                                HWDATA_reg <= PWDATA;
                            end
                            default: begin
                                HADDR      <= HADDR + 3'd4;
                                HWDATA_reg <= PWDATA;
                            end
                        endcase
                    end 
                    else begin // Single / Non-burst
                        HADDR      <= PADDR;
                        HWDATA_reg <= PWDATA;
                    end
                end
            endcase
        end
    end

    // 4. Data Phase (HWDATA generation aligned with HREADY)
    always @(posedge HCLK or negedge HRESETn) begin
        if (!HRESETn)
            HWDATA <= 32'b0;
        else if (HREADY)
            HWDATA <= HWDATA_reg;
    end

    // 5. Transfer Complete Indicator
    always @(*) begin
        if ((cs == NONSEQ || cs == SEQ) && ns == IDLE && HREADY)
            PDONE = 1'b1;
        else
            PDONE = 1'b0;
    end

endmodule