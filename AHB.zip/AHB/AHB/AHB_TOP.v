
// this module connects the AHB Master, Decoder, Slaves, and MUX modules
module AHB_TOP (
    // Global Signals
    input HCLK,
    input HRESETn,
    // Processor signals (Testbench interface)
    input [31:0] PADDR,
    input [31:0] PWDATA,
    input        PWRITE,
    input [2:0]  PSIZE,
    input [1:0]  PTRANS,
    input [2:0]  PBURST,
    output       PDONE
);
    // Internal interconnect wires (Fixed: Changed from reg to wire)
    // From Master to Slaves
    wire [31:0] HADDR;
    wire [31:0] HWDATA;
    wire        HWRITE;
    wire [2:0]  HSIZE;
    wire [1:0]  HTRANS;
    wire [2:0]  HBURST;

    // From Decoder
    wire [1:0]  HSELx_slaves;
    wire [1:0]  HSELx_Mux;

    // From Slaves to MUX
    wire        HREADYOUT_1;
    wire        HREADYOUT_2;
    wire        HRESP_Slave_1;
    wire        HRESP_Slave_2;
    wire [31:0] HRDATA_1;
    wire [31:0] HRDATA_2;

    // From MUX to Master & Slaves
    wire [31:0] HRDATA;
    wire        HREADY;
    wire        HRESP;

    // Instantiate the AHB Master
    AHB_Master master (
        .HCLK(HCLK),
        .HRESETn(HRESETn),
        .PADDR(PADDR),
        .PWDATA(PWDATA),
        .PWRITE(PWRITE),
        .PSIZE(PSIZE),
        .PTRANS(PTRANS),
        .PBURST(PBURST),
        .HADDR(HADDR),
        .HWDATA(HWDATA),
        .HWRITE(HWRITE),
        .HSIZE(HSIZE),
        .HTRANS(HTRANS),
        .HBURST(HBURST),
        .HREADY(HREADY),
        .HRESP(HRESP),
        .HRDATA(HRDATA),
        .PDONE(PDONE)
    );

    // Instantiate the Decoder
    AHB_Decoder decoder (
        .HADDR(HADDR),
        .HSELx_slaves(HSELx_slaves),
        .HSELx_Mux(HSELx_Mux)
    );

    // Instantiate AHB Slave 1
    AHB_Slave_1 slave1 (
        .HCLK(HCLK),
        .HRESETn(HRESETn),
        .HADDR(HADDR),
        .HWDATA(HWDATA),
        .HSELx_slaves(HSELx_slaves),
        .HWRITE(HWRITE),
        .HSIZE(HSIZE),
        .HTRANS(HTRANS),
        .HBURST(HBURST),
        .HREADY(HREADY),
        .HREADYOUT(HREADYOUT_1),
        .HRESP(HRESP_Slave_1),
        .HRDATA(HRDATA_1)
    );

    // Instantiate AHB Slave 2
    AHB_Slave_2 slave2 (
        .HCLK(HCLK),
        .HRESETn(HRESETn),
        .HADDR(HADDR),
        .HWDATA(HWDATA),
        .HSELx_slaves(HSELx_slaves),
        .HWRITE(HWRITE),
        .HSIZE(HSIZE),
        .HTRANS(HTRANS),
        .HBURST(HBURST),
        .HREADY(HREADY),
        .HREADYOUT(HREADYOUT_2),
        .HRESP(HRESP_Slave_2),
        .HRDATA(HRDATA_2)
    );

    // Instantiate Multiplexer
    AHB_MUX mux (
        .HRESP_Slave_1(HRESP_Slave_1),
        .HREADYOUT_1(HREADYOUT_1),
        .HRDATA_Slave_1(HRDATA_1),
        .HRESP_Slave_2(HRESP_Slave_2),
        .HREADYOUT_2(HREADYOUT_2),
        .HRDATA_Slave_2(HRDATA_2),        
        .HSELx_Mux(HSELx_Mux),
        .HRDATA(HRDATA),
        .HREADY(HREADY),
        .HRESP(HRESP)
    );

endmodule